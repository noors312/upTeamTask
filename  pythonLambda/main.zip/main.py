import datetime
import os

import boto3


def main(event, context):
    sqs = boto3.client('sqs', 'us-west-1')
    print(event)
    print(context)
    sqs.send_message(
        QueueUrl=os.environ.get('SQS_URL', ''),
        messageBody={
            'timestamp': datetime.datetime.today()
        }
    )
